import cv2
import numpy as np
from tkinter import *
from PIL import Image, ImageTk
from record_video import *

win = Tk()
win.geometry("1000x600+400+200")

color = "gray"
frame_1 = Frame(win, width=1000, height=600, bg=color).place(x=0, y=0)
label1 = Label(frame_1,bd=0)

def to_pil(img, label, x, y, w, h):
    img = cv2.resize(img, (w, h))
    # img = cv2.flip(img, 1)
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    image = Image.fromarray(img)
    pic = ImageTk.PhotoImage(image)
    label.configure(image=pic)
    label.image = pic
    label.place(x=x, y=y)


Model = cv2.dnn.readNetFromDarknet("model/cars.cfg", "model/cars_final.weights")
# CPU:
# net.setPreferableBackend(cv2.dnn.DNN_BACKEND_OPENCV)
# net.setPreferableTarget(cv2.dnn.DNN_TARGET_CPU)
# GPU:
Model.setPreferableBackend(cv2.dnn.DNN_BACKEND_CUDA)
Model.setPreferableTarget(cv2.dnn.DNN_TARGET_CUDA)


class_name = "car"

def detector(outputs, img):
    height, width, _ = img.shape
    bbox = []
    confid = []
    for output in outputs:
        for det in output:
            scores = det[5:]
            confidence = scores[0]
            if confidence > 0.1:
                w, h = int(det[2] * width), int(det[3] * height)
                x, y = int((det[0] * width) - w / 2), int((det[1] * height) - h / 2)
                bbox.append([x, y, w, h])
                confid.append(float(confidence))

    COLOR = (182, 247, 2)
    indicator = cv2.dnn.NMSBoxes(bbox, confid, 0.1, 0.3)
    counter =0
    for ind in indicator:
        i = ind[0]
        box = bbox[i]
        x, y, w, h = box[0], box[1], box[2], box[3]
        cv2.rectangle(img, (x, y), (x + w, y + h), COLOR, 3)
        cv2.putText(img,str(class_name)+"_"+str(int(confid[i]*100))+'%',(x,y-5),cv2.FONT_HERSHEY_COMPLEX,0.8,(3, 44, 252),2)
        counter +=1
        cv2.rectangle(img, (x, y), (x + 60, y + 30), COLOR, cv2.FILLED)
        cv2.putText(img, str(i+1), (x, y + 24),
                    cv2.FONT_HERSHEY_COMPLEX, 0.9, (0, 0, 0), 2)
    cv2.putText(img, str(counter), (1710, 90),
                cv2.FONT_HERSHEY_COMPLEX, 2, (0, 0, 0), 2)

    cv2.putText(img, 'Azu Technology', (830, 90),
                cv2.FONT_HERSHEY_SIMPLEX, 1.4, (0, 0, 0), 3)

cap = cv2.VideoCapture("DRONE.mp4")
def display():
    try:
        _, img = cap.read()
        blob = cv2.dnn.blobFromImage(img, 1 / 255, (320, 320), [0, 0, 0], 1, crop=False)
        Model.setInput(blob)
        layer_name = Model.getLayerNames()
        unconnected_layers = Model.getUnconnectedOutLayers()
        output = [layer_name[i[0] - 1] for i in unconnected_layers]
        output = Model.forward(output)
        detector(output, img)
        to_pil(img, label1, 45, 20, 900, 540)
        label1.after(20, display)
    except Exception:
        return True

display()
win.mainloop()
